// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key) {
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for performance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i) {
        // transform each character based on an xor of the key modded constrained to key length using a mod
        output[i] = source[i] ^ key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename) {
    // Set file to stream - input
    std::ifstream file_path(filename);
    std::string file_text;

    try {
        // File opened successfully
        if (file_path) {
            // Create a new string stream for which to buffer the file content to
            std::ostringstream stringStream;

            // Read the file buffer to the string stream buffer
            stringStream << file_path.rdbuf();

            // Output the buffer to the file_text variable
            file_text = stringStream.str();
        }
        // File failed to open
        else if (!file_path) {
            std::cerr << "Could not open the file - '" << filename << "'" << std::endl;
            exit(EXIT_FAILURE);
        }
    }
    catch (...) { // Catch exceptions - could not read file
        std::cout << "Failed to read file" << std::endl;
    }

    return file_text;
}

std::string get_student_name(const std::string& string_data) {
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos) { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data) {

    // create the file timestamp
    auto t = std::time(nullptr);
    struct tm buf;
    auto tm = localtime_s(&buf, &t);

    // Set file to a stream - output
    std::ofstream file_path(filename);

    try {
        // File was written successfully
        if (file_path) {
            file_path << student_name << "\n"; // Student Name
            file_path << std::put_time(&buf, "%Y-%m-%d") << "\n";  // Timestamp (yyyy-mm-dd)
            file_path << key << "\n"; // Key Used (ComputerScienceisFun!)
            file_path << data; // Data String (decrypted or encrypted)

            // Close the file
            file_path.close();
        }
        // File was not written successfully
        else if (!file_path) {
            std::cerr << "Could not write the file - '" << filename << "'" << std::endl;
            exit(EXIT_FAILURE);
        }
    }
    catch (...) { // Catch exceptions - could not write file
        std::cout << "Failed to write file" << std::endl;
    }

}

int main() {
    std::cout << "Encyption Decryption Test!" << std::endl;

    // input file format
    // Line 1: <students name>
    // Line 2: <Lorem Ipsum Generator website used> https://www.lipsum.com/
    // Lines 3+: <lorem ipsum generated with 3 paragraphs>
    //  Ut elementum bibendum ligula, sit amet ullamcorper ante vehicula non. Donec et arcu ut ante faucibus imperdiet faucibus et tellus. Duis luctus viverra dolor, vel sodales mauris feugiat ut. Duis viverra ante quis sapien sagittis, nec consectetur nisl rutrum. Suspendisse potenti. Duis venenatis aliquam purus, eget fringilla dolor blandit a. Morbi et nulla eu dui volutpat dapibus.
    //  Vestibulum in dolor felis. Etiam lorem tortor, congue vitae tellus ac, blandit tincidunt tortor. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Duis tristique erat non commodo scelerisque. Mauris pharetra finibus odio a fringilla. Ut in vehicula quam, id egestas sapien. Etiam porta diam nisl, eu consectetur eros convallis id. Aenean nisl urna, sagittis vel fringilla eget, imperdiet vitae sapien. Nulla nec blandit quam, et accumsan tortor. Morbi eu luctus lacus, sed finibus arcu.
    //  Sed non nibh nec arcu porttitor venenatis. Morbi viverra sem quis nibh consectetur ultricies eu vitae quam. Integer dictum dictum felis ut vulputate. Sed at faucibus nibh. In tristique elit dolor, eget faucibus quam ornare at. Cras ex mi, bibendum nec mattis et, dignissim finibus velit. Nulla et eros ullamcorper, sodales lectus ut, ultrices nulla. Proin scelerisque dolor sed elit aliquam, non maximus quam aliquam. In hac habitasse platea dictumst.

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "ComputerScienceisFun!";

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // encrypt source_string with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // students submit input file, encrypted file, decrypted file, source code file, and key used
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu


